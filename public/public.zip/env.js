export const firebaseConfig = {
 apiKey: "AIzaSyAgZxBaHiE_oDeJOBAQdcZcPe8hAmIk-ug",
  authDomain: "pylp2020-7eb13.firebaseapp.com",
  projectId: "pylp2020-7eb13",
  storageBucket: "pylp2020-7eb13.appspot.com",
  messagingSenderId: "513842090055",
  appId: "1:513842090055:web:471ee71e7ab07e4de76162"
};

